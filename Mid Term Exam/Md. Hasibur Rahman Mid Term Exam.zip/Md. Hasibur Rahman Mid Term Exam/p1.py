sentence = str(input("Enter a string: "))
reverse_str = sentence[:: -1]
print(reverse_str)