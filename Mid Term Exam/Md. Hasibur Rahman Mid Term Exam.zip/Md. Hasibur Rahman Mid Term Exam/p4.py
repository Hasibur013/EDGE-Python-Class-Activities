num1 = int(input("Enter num1: "))
num2 = int(input("Enter num2: "))

if num1 > num2:
    print("num1 greater than num2")
else:
    print("num2 greater than num2")
    
if num1 < num2:
    print("num2 greater than num2")
else:
    print("num1 greater than num2")
    
if num1 == num2:
    print("Both number are same")
else:
    print("Both number are not same")

if num1 != num2:
    print("Both number are not same")
else:
    print("Both number are same")
    
if num1 <= num2:
    print("num2 greater then or equal to num1")
else:
    print("num1 less than or equal to  num2")
    
if num1 >= num2:
    print("num1 greater then or equal to num2")
else:
    print("num2 less than or equal to  num1")