import statistics

lst = [2,4,6,8,9]

print("Mean: ", statistics.mean(lst))
print("Median: ", statistics.median(lst))
print("Mode: ", statistics.mode(lst))
