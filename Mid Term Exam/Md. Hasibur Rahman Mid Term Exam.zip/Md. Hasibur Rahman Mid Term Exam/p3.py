def eval(expre):
    result = int(expre[0])*(int(expre[3])+int(expre[5]))
    print(result)

expre = "3*(2+5)"
eval(expre)