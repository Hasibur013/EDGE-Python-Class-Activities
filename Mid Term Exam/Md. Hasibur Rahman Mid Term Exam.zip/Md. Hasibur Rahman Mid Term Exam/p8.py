length = 5

list1 = []
list2 = []

print("Enter 5 numbers for list1: ")
for i in range(5):
    list1.append(int(input()))

