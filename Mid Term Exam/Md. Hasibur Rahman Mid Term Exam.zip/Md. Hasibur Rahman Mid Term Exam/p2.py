input = 1
print(type(input))


input2 = "Hasib"
print(type(input2))